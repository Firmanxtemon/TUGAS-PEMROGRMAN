﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AplikasiSelamatDatang
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            lblKeterangan.Text = " Selamat Datang di pemrogrman c#";

        }
        private void btnKeterangan2_Click(object sender, EventArgs e)
        {

            lblKeterangan.Text = "Begitu mudahnya membuat aplikasi berbasis windows";
        }
    }
}
